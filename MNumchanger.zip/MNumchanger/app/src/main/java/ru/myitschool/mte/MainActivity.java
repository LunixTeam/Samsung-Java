package ru.myitschool.mte;

import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    Button startBtn;
    Button stopBtn;
    Handler h;
    int n = 0;
    boolean run = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.num_iteration);
        startBtn = findViewById(R.id.button_start);
        stopBtn = findViewById(R.id.button_stop);

        h = new Handler();

        Runnable r = new Runnable() {
            public void run() {
                if (run) {
                    n++;
                    if (n > 3) n = 1;
                    textView.setText(n + "");
                    h.postDelayed(this, 1000);
                }
            }
        };

        startBtn.setOnClickListener(v -> {
            if (!run) {
                run = true;
                n = 1;
                textView.setText("1");
                h.postDelayed(r, 1000);
            }
        });

        stopBtn.setOnClickListener(v -> {
            run = false;
            h.removeCallbacks(r);
        });
    }
}